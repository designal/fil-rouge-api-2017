package fr.centralesupelec.sio.model;

/**
 * An entity class for an API error
 */
public class Error {

    private String error;

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

}
